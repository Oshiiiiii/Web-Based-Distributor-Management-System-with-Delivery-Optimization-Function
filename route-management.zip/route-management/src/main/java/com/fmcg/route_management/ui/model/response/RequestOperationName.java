package com.fmcg.route_management.ui.model.response;

public enum RequestOperationName {
	DELETE
}
