package com.fmcg.route_management.ui.model.response;
import java.io.Serializable;
import java.util.List;

public class RouteCalculationResponse implements Serializable {
    private static final long serialVersionUID = 7972780255071376780L;
    
    private String routeSummary;
    private String duration;
    private String distance;
    private List<String> waypoints;

    // Getters and Setters
    public String getRouteSummary() {
        return routeSummary;
    }

    public void setRouteSummary(String routeSummary) {
        this.routeSummary = routeSummary;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public List<String> getWaypoints() {
        return waypoints;
    }

    public void setWaypoints(List<String> waypoints) {
        this.waypoints = waypoints;
    }

    @Override
    public String toString() {
        return "RouteCalculationResponse{" +
                "routeSummary='" + routeSummary + '\'' +
                ", duration='" + duration + '\'' +
                ", distance='" + distance + '\'' +
                ", waypoints=" + (waypoints != null ? waypoints.size() + " waypoints" : "No waypoints") +
                '}';
    }
}
