package com.fmcg.route_management.ui.contorller;

import com.fmcg.route_management.ui.model.response.RouteCalculationResponse;
import com.fmcg.route_management.service.RouteOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/RouteCalculation")
public class RouteCalculationController {

    @Autowired
    private RouteOrderService routeOrderService;

    @GetMapping(path = "/calculateRoute", produces = {MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE})
    public RouteCalculationResponse calculateRoute(@RequestParam(value = "origin") String origin,
                                                   @RequestParam(value = "destination") String destination,
                                                   @RequestParam(value = "waypoints", required = false) String waypoints) {
        // Call service for route calculation
        RouteCalculationResponse response = routeOrderService.calculateRoute(origin, destination, waypoints);
        return response;
    }
}
