package com.fmcg.route_management.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        // Allow CORS for the `/api/**` endpoint
        registry.addMapping("/api/**")  // Adjust the mapping path if necessary
        .allowedOrigins("http://localhost")  // Allow localhost for any port
        .allowedMethods("GET", "POST", "PUT", "DELETE")  // Allowed HTTP methods
        .allowedHeaders("*")  // Allow all headers
        .allowCredentials(true);  // Allow cookies if needed
    }
}