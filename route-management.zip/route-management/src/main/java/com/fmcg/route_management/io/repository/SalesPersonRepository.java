package com.fmcg.route_management.io.repository;

import com.fmcg.route_management.io.entity.SalesPerson;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;


/**
 * Spring Data repository for the Product entity.
 */
@Repository
public interface SalesPersonRepository extends JpaRepository<SalesPerson, Long> {

	Optional<SalesPerson> findById(Long id);

	SalesPerson findBySalesmanName(String salesmanName);

}
