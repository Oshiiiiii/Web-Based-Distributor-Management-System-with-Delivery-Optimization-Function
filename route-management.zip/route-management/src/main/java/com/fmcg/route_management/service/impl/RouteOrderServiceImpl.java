package com.fmcg.route_management.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import jakarta.transaction.Transactional;

import com.fmcg.route_management.exceptions.ResourceAlreadyExistsException;
import com.fmcg.route_management.exceptions.ResourceNotFoundException;
import com.fmcg.route_management.io.entity.PickList;
import com.fmcg.route_management.io.entity.RouteOrder;
import com.fmcg.route_management.io.entity.Distributor; // Assuming you have this entity
import com.fmcg.route_management.io.repository.PickListRepository;
import com.fmcg.route_management.io.repository.RouteOrderRepository;
import com.fmcg.route_management.io.repository.DistributorRepository;
import com.fmcg.route_management.service.RouteOrderService;
import com.fmcg.route_management.shared.dto.RouteOrderDTO;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;


@Service
public class RouteOrderServiceImpl implements RouteOrderService {

	@Autowired
	ModelMapper mapper;

	@Autowired
	RouteOrderRepository repository;
	
	@Autowired
	PickListRepository pickListRepository;

	@Override
	public RouteOrderDTO save(RouteOrderDTO dto) {

		if (repository.findById(dto.getId()) != null)
			throw new ResourceAlreadyExistsException("Record already exists");

		RouteOrder entity = mapper.map(dto, RouteOrder.class);
		RouteOrder storage = repository.save(entity);

		return mapper.map(storage, RouteOrderDTO.class);
	}

	@Override
	public List<RouteOrderDTO> getList(int page, int limit) {
		List<RouteOrderDTO> returnValue = new ArrayList<>();

		if (page > 0)
			page = page - 1;

		Pageable pageableRequest = PageRequest.of(page, limit);

		Page<RouteOrder> resourcePage = repository.findAll(pageableRequest);
		List<RouteOrder> resource = resourcePage.getContent();

		for (RouteOrder entity : resource) {
			returnValue.add(mapper.map(entity, RouteOrderDTO.class));
		}

		return returnValue;
	}

	@Override
	public RouteOrderDTO get(Long id) {
		Optional<RouteOrder> entity = repository.findById(id);

		if (entity.isPresent()) {
			return mapper.map(entity.get(), RouteOrderDTO.class);
		} else {
			throw new ResourceNotFoundException("Requested Route Order is not found.");
		}
	}

	@Transactional
	@Override
	public void delete(Long id) {
		Optional<RouteOrder> entity = repository.findById(id);

		if (entity.isPresent()) {
			repository.delete(entity.get());
		} else {
			throw new ResourceNotFoundException("Requested Route Order is not found.");
		}
	}

	@Override
	public RouteOrderDTO update(Long id, RouteOrderDTO dto) {

		Optional<RouteOrder> entity = repository.findById(id);
		if (entity.isPresent()) {
			entity.get().setOrderNo(dto.getOrderNo());
			
			Optional<PickList> pickList = pickListRepository.findById(id);
			if (pickList.isPresent()) {
				entity.get().setPickList(pickList.get());
			} else {
				throw new ResourceNotFoundException("Selected picklist is not found.");
			}
			RouteOrder updatedResources = repository.save(entity.get());
			return mapper.map(updatedResources, RouteOrderDTO.class);
		} else {
			throw new ResourceNotFoundException("Requested Route Order is not found.");
		}

	}
    @Override
    public RouteOrderDTO optimizeRoute(List<Long> locationIds) {
        // Fetch the distributor locations based on the location IDs
        List<Distributor> locations = distributorRepository.findAllById(locationIds);

        // Calculate the optimized order of locations (this could be based on a real algorithm or mock logic)
        List<String> optimizedOrder = calculateOptimizedRoute(locations);

        // Generate Google Maps Directions URL
        String googleMapsUrl = "https://www.google.com/maps/dir/" + String.join("/", optimizedOrder);

        // Create a RouteOrderDTO to return
        RouteOrderDTO routeOrderDTO = new RouteOrderDTO();
        routeOrderDTO.setOptimizedOrder(optimizedOrder);
        routeOrderDTO.setGoogleMapsUrl(googleMapsUrl);

        return routeOrderDTO;
    }

    // Mock method to calculate optimized route (for now just returning location names in the given order)
    private List<String> calculateOptimizedRoute(List<Distributor> locations) {
        return locations.stream()
                        .map(Distributor::getName)
                        .collect(Collectors.toList());
    }


}
