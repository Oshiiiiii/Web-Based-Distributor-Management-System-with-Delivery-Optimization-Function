package com.fmcg.route_management.service;

import com.fmcg.route_management.shared.dto.DistributorDTO;
import com.fmcg.route_management.ui.model.response.RouteCalculationResponse;

import java.util.List;

public interface DistributorService {

	DistributorDTO save(DistributorDTO dto);

	List<DistributorDTO> getList(int page, int limit);
	List<DistributorDTO> getAllLocations();

	DistributorDTO get(Long id);

	void delete(Long id);

	DistributorDTO update(Long id, DistributorDTO dto);
	 RouteCalculationResponse optimizeRoute(List<String> locations);  // Add this method
}
