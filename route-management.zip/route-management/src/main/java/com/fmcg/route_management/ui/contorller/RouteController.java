package com.fmcg.route_management.ui.contorller;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class RouteController {

    private static final String GOOGLE_MAPS_API_KEY = "AIzaSyBMEUlhEvqPhuTi61XcTb96mq3q-7BWeek";

 
    @PostMapping("/optimize-route")
    public ResponseEntity<Map<String, Object>> optimizeRoute(@RequestBody Map<String, Object> request) {
        List<String> locations = (List<String>) request.get("locations");

        // Validate input
        if (locations == null || locations.size() < 2) {
            return ResponseEntity.badRequest().body(Map.of("error", "At least two locations required"));
        }

        // Simulating route optimization (shuffling for demonstration purposes)
        List<String> optimizedOrder = new ArrayList<>(locations);
        Collections.shuffle(optimizedOrder.subList(1, optimizedOrder.size() - 1)); // Shuffle waypoints for demonstration

        // Simulate total distance calculation by generating random distances between locations
        double totalDistance = 0.0;
        for (int i = 0; i < optimizedOrder.size() - 1; i++) {
            totalDistance += calculateDistanceBetweenLocations(optimizedOrder.get(i), optimizedOrder.get(i + 1));
        }

        // Return the simulated result with the optimized order and total distance
        Map<String, Object> response = new HashMap<>();
        response.put("optimizedOrder", optimizedOrder);
        response.put("totalDistance", totalDistance);

        return ResponseEntity.ok(response);
    }

    // Simulate calculating the distance between two locations (random for the sake of simulation)
    private double calculateDistanceBetweenLocations(String location1, String location2) {
        // Here, we simulate distance by returning a random value between 5 km and 20 km
        Random random = new Random();
        return 5 + (15 * random.nextDouble()); // Random distance between 5 and 20 km
    }
}