package com.fmcg.route_management.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.fmcg.route_management.exceptions.ResourceAlreadyExistsException;
import com.fmcg.route_management.exceptions.ResourceNotFoundException;
import com.fmcg.route_management.io.entity.Distributor;
import com.fmcg.route_management.io.repository.DistributorRepository;
import com.fmcg.route_management.service.DistributorService;
import com.fmcg.route_management.shared.dto.DistributorDTO;
import com.fmcg.route_management.ui.model.response.RouteCalculationResponse;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.ArrayList;

@Service
public class DistributorServiceImpl implements DistributorService {

    @Autowired
    ModelMapper mapper;

    @Autowired
    DistributorRepository repository;

	@Override
    public RouteCalculationResponse optimizeRoute(List<String> locations) {
        // Step 1: Validate input
        if (locations == null || locations.isEmpty()) {
            throw new IllegalArgumentException("Locations cannot be null or empty");
        }

        // Step 2: Declare variables
        List<String> optimizedOrder = new ArrayList<>();
        String googleMapsUrl = "";

        // Step 3: Logic to optimize route (mock logic for now)
        optimizedOrder = getOptimizedOrder(locations); // placeholder: replace with real logic
        googleMapsUrl = generateGoogleMapsUrl(optimizedOrder);

        // Step 4: Create RouteCalculationResponse
        RouteCalculationResponse response = new RouteCalculationResponse();
        response.setRouteSummary("Optimized route summary"); // Placeholder: Add a real summary based on logic
        response.setDuration("Estimated Duration: 45 mins");  // Placeholder: Use real data if available
        response.setDistance("Total Distance: 15 miles");     // Placeholder: Use real data if available
        response.setWaypoints(optimizedOrder);

        // Step 5: Return the response
        return response;
    }

    // Mock optimization logic (you can replace this with actual route optimization algorithm)
    private List<String> getOptimizedOrder(List<String> locations) {
        return new ArrayList<>(locations); // placeholder: returns input order (replace with real optimization logic)
    }

    // Generates a Google Maps link (this is just a basic URL generator)
    private String generateGoogleMapsUrl(List<String> locations) {
        StringBuilder url = new StringBuilder("https://www.google.com/maps/dir/");
        for (String location : locations) {
            url.append(location.replace(" ", "+")).append("/"); // Replace spaces with "+" for the URL
        }
        return url.toString();
    }
    @Override
    public DistributorDTO save(DistributorDTO dto) {
        if (repository.findByDistributorCode(dto.getDistributorCode()) != null)
            throw new ResourceAlreadyExistsException("Record already exists");

        Distributor entity = mapper.map(dto, Distributor.class);
        Distributor storage = repository.save(entity);

        return mapper.map(storage, DistributorDTO.class);
    }

    @Override
    public List<DistributorDTO> getList(int page, int limit) {
        // Your pagination logic for distributors
        return null; // Placeholder
    }

    @Override
    public DistributorDTO get(Long id) {
        Optional<Distributor> entity = repository.findById(id);

        if (entity.isPresent()) {
            return mapper.map(entity.get(), DistributorDTO.class);
        } else {
            throw new ResourceNotFoundException("Requested Distributor is not found.");
        }
    }

    @Transactional
    @Override
    public void delete(Long id) {
        Optional<Distributor> entity = repository.findById(id);

        if (entity.isPresent()) {
            repository.delete(entity.get());
        } else {
            throw new ResourceNotFoundException("Requested Distributor is not found.");
        }
    }

    @Override
    public DistributorDTO update(Long id, DistributorDTO dto) {
        Optional<Distributor> entity = repository.findById(id);
        if (entity.isPresent()) {
            // Update distributor fields
            return mapper.map(repository.save(entity.get()), DistributorDTO.class);
        } else {
            throw new ResourceNotFoundException("Requested Distributor is not found.");
        }
    }

    @Override
    public List<DistributorDTO> getAllLocations() {
        List<Distributor> locations = repository.findAll(); // Using DistributorRepository to fetch all distributors

        // Convert to DTOs
        return locations.stream()
                .map(location -> mapper.map(location, DistributorDTO.class))
                .collect(Collectors.toList());
    }
}
