import React, { useState } from 'react';
import axios from 'axios';
import MapView from './MapView'

export default function RouteForm() {
  const [locations, setLocations] = useState([]);
  const [newLocation, setNewLocation] = useState('');
  const [directions, setDirections] = useState(null)
  const [shopDetails, setShopDetails] = useState({
    name: '',
    address: '',
    phone: '',
    email: '',
    openHour: '',
    closeHour: '',
    deliveryWindow: '',
    priority: 'low',
  });

    // Add loading and error message state
    const [loading, setLoading] = useState(false); // For loading state
    const [errorMessage, setErrorMessage] = useState(''); // For error message

  const [optimized, setOptimized] = useState(null);

  const handleAddLocation = () => {
    if (newLocation.trim() !== '') {
      setLocations([
        ...locations,
        { location: newLocation.trim(), details: shopDetails },
      ]);
      setNewLocation('');
      setShopDetails({
        name: '',
        address: '',
        phone: '',
        email: '',
        openHour: '',
        closeHour: '',
        deliveryWindow: '',
        priority: 'low',
      });
    }
  };

  const handleOptimize = async () => {

    if (locations.length < 2) {
      setErrorMessage('You need at least 2 locations to optimize the route.');
      return;
    }
      // Start loading
  setLoading(true);
  setErrorMessage(''); // Reset error message

    try {
      const res = await axios.post('http://localhost:9090/api/optimize-route', {
        locations: locations.map((loc) => loc.location),
      });
      setOptimized(res.data);

       // Build route on map
       const waypoints = res.data.optimizedOrder.slice(1, -1).map((address) => ({
        location: address,
        stopover: true,
      }))

      const directionsService = new window.google.maps.DirectionsService()
      directionsService.route(
        {
          origin: res.data.optimizedOrder[0],
          destination: res.data.optimizedOrder[res.data.optimizedOrder.length - 1],
          waypoints: waypoints,
          travelMode: window.google.maps.TravelMode.DRIVING,
        },
        (result, status) => {
          if (status === 'OK') {
            setDirections(result)
          } else {
            console.error('Directions request failed:', status)
          }
        }
      )

    } catch (err) {
      console.error('Error optimizing route', err);
      setErrorMessage('Failed to optimize route.')
    } finally {
      setLoading(false)
    
    }
  };

  const inputStyle = {
    padding: '8px',
    margin: '5px 0',
    width: '100%',
    borderRadius: '6px',
    border: '1px solid #ccc',
  };

  const buttonStyle = {
    backgroundColor: '#007BFF', // Blue
    color: '#fff',
    border: 'none',
    padding: '10px 15px',
    marginTop: '10px',
    borderRadius: '6px',
    cursor: 'pointer',
  };

  const containerStyle = {
    fontFamily: 'Arial, sans-serif',
    display: 'flex',
    height: '100vh',
    backgroundColor: '#f4f6f8',
  };

  const sidebarStyle = {
    width: '350px',
    padding: '20px',
    backgroundColor: '#fff',
    borderRight: '2px solid #eee',
    boxShadow: '2px 0 5px rgba(0,0,0,0.05)',
  };

  const dashboardStyle = {
    flex: 1,
    padding: '30px',
  };

  return (
    <div style={containerStyle}>
      <div style={sidebarStyle}>
        <h2 style={{ color: '#e74c3c' }}>Shop Details</h2>
        {Object.keys(shopDetails).map((key) =>
          key !== 'priority' ? (
            <input
              key={key}
              style={inputStyle}
              type={key === 'email' ? 'email' : 'text'}
              value={shopDetails[key]}
              onChange={(e) => setShopDetails({ ...shopDetails, [key]: e.target.value })}
              placeholder={key
                .replace(/([A-Z])/g, ' $1')
                .replace(/^./, (str) => str.toUpperCase())}
            />
          ) : null
        )}
        <select
          style={{ ...inputStyle, backgroundColor: '#fff' }}
          value={shopDetails.priority}
          onChange={(e) => setShopDetails({ ...shopDetails, priority: e.target.value })}
        >
          <option value="low">Low Priority</option>
          <option value="medium">Medium Priority</option>
          <option value="high">High Priority</option>
        </select>

        <h3 style={{ color: '#f39c12' }}>Add Location</h3>
        <input
          style={inputStyle}
          type="text"
          value={newLocation}
          onChange={(e) => setNewLocation(e.target.value)}
          placeholder="Enter location"
        />
        <button style={buttonStyle} onClick={handleAddLocation}>
          Add Location
        </button>

        <ul style={{ marginTop: '15px', paddingLeft: '20px' }}>
          {locations.map((loc, idx) => (
            <li key={idx} style={{ marginBottom: '10px', fontSize: '14px' }}>
              <strong style={{ color: '#007BFF' }}>{loc.location}</strong> - {loc.details.name}
              <br />
              <small>{loc.details.address}</small>
              <br />
              Phone: {loc.details.phone} | Email: {loc.details.email}
              <br />
              Hours: {loc.details.openHour} - {loc.details.closeHour}
              <br />
              Delivery: {loc.details.deliveryWindow}, Priority: {loc.details.priority}
            </li>
          ))}
        </ul>
      </div>

      <div style={dashboardStyle}>
        <h2 style={{ color: '#2c3e50' }}>Optimize Delivery Route</h2>
        <button
          style={{
            ...buttonStyle,
            backgroundColor: locations.length < 2 ? '#ccc' : '#e67e22', // Orange
            cursor: locations.length < 2 ? 'not-allowed' : 'pointer',
          }}
          onClick={handleOptimize}
          disabled={locations.length < 2}
        >
        {loading ? <span>Loading...</span> : 'Optimize'}
        </button>

        {errorMessage && (
          <p style={{ color: 'red', marginTop: '10px' }}>{errorMessage}</p>
        )}


        {optimized && (
          <div style={{ marginTop: '20px' }}>
            <h4 style={{ color: '#27ae60' }}>Optimized Order:</h4>
            <ul>
              {optimized.optimizedOrder.map((loc, idx) => (
                <li key={idx}>{loc}</li>
              ))}
            </ul>
            <p>Total Distance: {optimized.totalDistance} km</p>
          </div>
        )}

        {directions && <MapView directions={directions} />}
      </div>
    </div>
  );
}
