// src/components/route-management/MapView.js

import React from 'react'

const containerStyle = {
  width: '100%',
  height: '400px',
  borderRadius: '12px',
  boxShadow: '0 4px 10px rgba(0,0,0,0.1)',
}

const MapView = ({ directions }) => {
  return (
    <div style={containerStyle}>
      <h4 style={{ padding: '1rem' }}>Map temporarily removed for debugging</h4>
    </div>
  )
}

export default MapView
