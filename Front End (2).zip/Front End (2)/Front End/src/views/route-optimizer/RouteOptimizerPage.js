import React from 'react'
import { CRow, CCol, CCard, CCardHeader, CCardBody } from '@coreui/react'
import RouteForm from '../../components/route-management/RouteForm'

const RouteOptimizerPage = () => {
  return (
    <CRow>
      <CCol xs={12}>
        <CCard>
          <CCardHeader>
            <strong>Delivery Route Optimizer</strong>
          </CCardHeader>
          <CCardBody>
            <RouteForm />
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  )
}

export default RouteOptimizerPage
