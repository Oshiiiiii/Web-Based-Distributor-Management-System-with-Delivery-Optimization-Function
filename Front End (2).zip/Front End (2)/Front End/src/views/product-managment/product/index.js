import React, { Component } from 'react';
import '../../distributor-managment/distributor-master/styles.css';
import { Button, Card, CardBody, CardHeader, Col, Row } from 'reactstrap';
import LabelInput from "../../../components/input/txtlbl/index";
//import { MDBDataTable } from 'mdbreact';
import { Button as SementicBtn, Form, Icon, Input } from 'semantic-ui-react';
import { Spin, Tooltip, Icon as AntdIcon } from "antd";
import DrpDwn from "../../../components/dropdown/index";
import Lbl from "../../../components/label/index";
import Update from '../../distributor-managment/distributor-master/update/index';

class App extends Component {
    state = {
        tblcolumns: [

            {
                label: 'Distributor Code',
                field: 'code',
                sort: 'asc'
            },
            {
                label: 'Distributor Name',
                field: 'name',
                sort: 'asc'
            },
            {
                label: 'Address',
                field: 'address',
                sort: 'asc'
            },
            {
                label: 'Contact',
                field: 'contact',
                sort: 'asc'


            },
            {
                label: 'Action',
                field: 'action',
                sort: 'asc'
            }
        ],
        tbldata: [
            {
                code: "C001",
                name: "Test",
                address: "Colombo",
                contact: "0771234567"
            },
            {
                code: "C002",
                name: "Test",
                address: "Colombo",
                contact: "0771234567"
            },
            {
                code: "C002",
                name: "Test",
                address: "Colombo",
                contact: "0771234567"
            },

        ],
        isUpdate: false,
        memberdata: null
    }

    updateMember = (obj) => {

        this.setState({
            isUpdate: true,
            memberdata: obj
        })
    };


    render() {
        const rows = [];
        if (this.state.tbldata.length !== 0) {
            this.state.tbldata.map((row, index) => {
                rows.push(
                    {
                        code: row.code,
                        name: row.name,
                        address: row.address,
                        contact: row.contact,
                        action:
                            <div>
                                <SementicBtn circular icon='edit'
                                onClick={() => this.updateMember(row)}
                                />
                                <SementicBtn className="cus-btn" circular icon='trash alternate'
                                //  onClick={() => this.deleteReception(row.userId,row.userName)}
                                />
                            </div>
                    }
                )
            });
        }
        let columns = this.state.tblcolumns;
        let table_data = { columns, rows };

        return (
            <div>
                {
                    this.state.isUpdate ?
                        <Update data={this.state.memberdata} refreshData={this.clearFeilds} closeModal={() => this.setState({ isUpdate: false })} /> : null
                }

                <Card>
                    <CardHeader>Product Managment</CardHeader>
                    <CardBody>
                        <Row>
                            <Col xs="12" lg={"12"} md={"12"} className={"padd_grap"}>
                                <Row>
                                    <Col lg={6}>
                                        <Form>
                                            <Col className={"none-padding"} lg={12}>
                                                <Lbl required>Distributor ID</Lbl>
                                                <LabelInput
                                                    placeholder={"Distributor ID"}
                                                //   value={this.state.name}
                                                //   onChange={this.handleChange('name')
                                                // }
                                                />
                                            </Col>

                                            <Col className={"none-padding"} lg={12}>
                                                <Lbl required>Name</Lbl>
                                                <LabelInput
                                                    placeholder={"Name"}
                                                //   value={this.state.username}
                                                //   onChange={this.handleChange('username')}
                                                />
                                            </Col>

                                            <Col className={"none-padding"} lg={12}>
                                                <Lbl required>Contact</Lbl>
                                                <LabelInput
                                                    placeholder={"Contact"}
                                                //   value={this.state.email}
                                                //   onChange={this.handleChange('email')}
                                                />
                                            </Col>

                                            <Col className={"none-padding"} lg={12}>
                                                <Lbl required>E-mail</Lbl>
                                                <LabelInput
                                                    placeholder={"E-mail"}
                                                //   value={this.state.email}
                                                //   onChange={this.handleChange('email')}
                                                />
                                            </Col>

                                        </Form>
                                    </Col>

                                    <Col lg={6}>
                                        <Form>
                                            <Col className={"none-padding"} lg={12}>
                                                <Lbl required>Vat Number</Lbl>
                                                <Input id={"password-field"} type={"Vat Number"}
                                                    //    onChange={this.handleChange('password')}
                                                    //    value={this.state.password}
                                                    style={{ width: '100%' }}
                                                    //    icon={<Icon onMouseUp={() => this.viewPassword(false)}
                                                    //                onMouseDown={() => this.viewPassword(true)} name='eye' circular link/>}
                                                    placeholder='Vat Number' />
                                            </Col>

                                            <Col className={"none-padding"} lg={12}>
                                                <Lbl required>Vat Status</Lbl>
                                                <DrpDwn
                                                    multiple
                                                    placeholder={"Vat Status"}
                                                //   options={this.state.branch_list}
                                                //   value={this.state.selected_list}
                                                //   onChange={this.dropDownChange('branch')}
                                                />
                                            </Col>
                                        </Form>

                                        <Row>
                                            <Col className="marginTop" xs={12} sm={12} md={12} lg={12}>
                                                <center>
                                                    <Button
                                                        className="addBtn"
                                                        color="primary"
                                                    // onClick={e => this.addReception(e, 'addReception')}
                                                    >Add Product</Button>

                                                    <Tooltip placement="topLeft" title="Clear input fields">
                                                        <SementicBtn circular icon='refresh'
                                                        // onClick={this.clearFeilds}
                                                        />
                                                    </Tooltip>

                                                </center>
                                            </Col>
                                        </Row>
                                    </Col>
                                </Row>
                            </Col>
                        </Row>
                    </CardBody>
                </Card>

                <Card>
                    <CardHeader>All Products</CardHeader>
                    <CardBody>
                        {/* <Spin
                            // spinning={this.state.isLoadReception}
                            delay={10}
                        // indicator={<AntdIcon type="loading" style={{ fontSize: 24 }} spin={"true"} />}
                        > }
                        <MDBDataTable
                            searching={true}
                            displayEntries={false}
                            entries={5}
                            responsive
                            responsiveSm
                            responsiveMd
                            responsiveLg
                            responsiveXl
                            bordered
                            hover
                            data={table_data}
                        />*/}
                        {/* </Spin> */}
                    </CardBody>
                </Card>
            </div>
        )
    }
}

export default App;
