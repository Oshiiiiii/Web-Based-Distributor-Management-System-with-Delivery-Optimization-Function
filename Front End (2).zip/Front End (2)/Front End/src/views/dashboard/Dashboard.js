import React, { lazy } from 'react'

import {
  CCard,
  CCardBody,
  CCardHeader,
} from '@coreui/react'

// Lazy-loaded widgets
const WidgetsDropdown = lazy(() => import('../widgets/WidgetsDropdown.js'))
// const WidgetsBrand = lazy(() => import('../widgets/WidgetsBrand.js')) // optional

const Dashboard = () => {
  return (
    <>
      {/* Top widgets section */}
      <WidgetsDropdown />

    </>
  )
}

export default Dashboard
