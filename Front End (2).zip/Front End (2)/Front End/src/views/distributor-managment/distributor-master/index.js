import React, { Component } from 'react';
import './styles.css';
import { Button, Card, CardBody, CardHeader, Col, Row } from 'reactstrap';
import LabelInput from "../../../components/input/txtlbl/index";
//import { MDBDataTable } from 'mdbreact';
//import { Table } from 'antd';
import { Button as SementicBtn, Form, Icon, Input } from 'semantic-ui-react';
import { Spin, Tooltip, Icon as AntdIcon } from "antd";
import DrpDwn from "../../../components/dropdown/index";
import Lbl from "../../../components/label/index";
import Update from '../distributor-master/update/index';

class App extends Component {
    state = {
        tblcolumns: [

            {
                label: 'Distributor Code',
                field: 'code',
                sort: 'asc'
            },
            {
                label: 'Distributor Name',
                field: 'name',
                sort: 'asc'
            },
            {
                label: 'Address',
                field: 'address',
                sort: 'asc'
            },
            {
                label: 'Contact',
                field: 'contact',
                sort: 'asc'


            },
            {
                label: 'Action',
                field: 'action',
                sort: 'asc'
            }
        ],
        tbldata: [
            {
                code: "C001",
                name: "Test",
                address: "Colombo",
                contact: "0771234567"
            },
            {
                code: "C002",
                name: "Test",
                address: "Colombo",
                contact: "0771234567"
            },
            {
                code: "C002",
                name: "Test",
                address: "Colombo",
                contact: "0771234567"
            },

        ],
        isUpdate: false,
        memberdata: null,
        id: "",
        name: "",
        contact: "",
        email: "",
        vatnumber: "",
        vatstatus: ""
    }

    updateMember = (obj) => {

        this.setState({
            isUpdate: true,
            memberdata: obj
        })
    };

    sendToBackEnd = () => {
        const { name, contact, email, vatnumber, vatstatus } = this.state;
        const obj = {
            "name": name,
            "contact": contact,
            "email": email,
            "vatnumber": vatnumber,
            "vatstatus": vatstatus
        }
    }

    getAllMembers() {

    }

    componentDidMount() {
        this.getAllMembers();
    }

    clearFeilds = () => {
        this.setState({
            id: "",
            name: "",
            contact: "",
            email: "",
            vatnumber: "",
            vatstatus: ""
        })
    }


    render() {
        const { id, name, contact, email, vatnumber, vatstatus } = this.state;
        const rows = [];
        if (this.state.tbldata.length !== 0) {
            this.state.tbldata.map((row, index) => {
                rows.push(
                    {
                        code: row.code,
                        name: row.name,
                        address: row.address,
                        contact: row.contact,
                        action:
                            <div>
                                <SementicBtn circular icon='edit'
                                    onClick={() => this.updateMember(row)}
                                />
                                <SementicBtn className="cus-btn" circular icon='trash alternate'
                                //  onClick={() => this.deleteReception(row.userId,row.userName)}
                                />
                            </div>
                    }
                )
            });
        }
       

        return (
            <div>
                {
                    this.state.isUpdate ?
                        <Update data={this.state.memberdata} refreshData={this.clearFeilds} closeModal={() => this.setState({ isUpdate: false })} /> : null
                }

                <Card>
                    <CardHeader>Distributor Managment</CardHeader>
                    <CardBody>
                        <Row>
                            <Col xs="12" lg={"12"} md={"12"} className={"padd_grap"}>
                                <Row>
                                    <Col lg={6}>
                                        <Form>
                                            <Col className={"none-padding"} lg={12}>
                                                <Lbl required>Distributor ID</Lbl>
                                                <LabelInput
                                                    placeholder={"Distributor ID"}
                                                    value={id}
                                                //   onChange={this.handleChange('name')
                                                // }
                                                />
                                            </Col>

                                            <Col className={"none-padding"} lg={12}>
                                                <Lbl required>Name</Lbl>
                                                <LabelInput
                                                    placeholder={"Name"}
                                                    value={name}
                                                //   onChange={this.handleChange('username')}
                                                />
                                            </Col>

                                            <Col className={"none-padding"} lg={12}>
                                                <Lbl required>Contact</Lbl>
                                                <LabelInput
                                                    placeholder={"Contact"}
                                                    value={contact}
                                                //   onChange={this.handleChange('email')}
                                                />
                                            </Col>

                                            <Col className={"none-padding"} lg={12}>
                                                <Lbl required>E-mail</Lbl>
                                                <LabelInput
                                                    placeholder={"E-mail"}
                                                    value={email}
                                                //   onChange={this.handleChange('email')}
                                                />
                                            </Col>

                                        </Form>
                                    </Col>

                                    <Col lg={6}>
                                        <Form>
                                            <Col className={"none-padding"} lg={12}>
                                                <Lbl required>Vat Number</Lbl>
                                                <Input id={"password-field"} type={"Vat Number"}
                                                    //    onChange={this.handleChange('password')}
                                                    value={vatnumber}
                                                    style={{ width: '100%' }}
                                                    //    icon={<Icon onMouseUp={() => this.viewPassword(false)}
                                                    //                onMouseDown={() => this.viewPassword(true)} name='eye' circular link/>}
                                                    placeholder='Vat Number' />
                                            </Col>

                                            <Col className={"none-padding"} lg={12}>
                                                <Lbl required>Vat Status</Lbl>
                                                <DrpDwn
                                                    multiple
                                                    placeholder={"Vat Status"}
                                                    //   options={this.state.branch_list}
                                                    value={vatstatus}
                                                //   onChange={this.dropDownChange('branch')}
                                                />
                                            </Col>
                                        </Form>

                                        <Row>
                                            <Col className="marginTop" xs={12} sm={12} md={12} lg={12}>
                                                <center>
                                                    <Button
                                                        className="addBtn"
                                                        color="primary"
                                                    // onClick={e => this.addReception(e, 'addReception')}
                                                    >Add Member</Button>

                                                    <Tooltip placement="topLeft" title="Clear input fields">
                                                        <SementicBtn circular icon='refresh'
                                                            onClick={this.clearFeilds}
                                                        />
                                                    </Tooltip>

                                                </center>
                                            </Col>
                                        </Row>
                                    </Col>
                                </Row>
                            </Col>
                        </Row>
                    </CardBody>
                </Card>

                <Card>
                    <CardHeader>All Members</CardHeader>
                    <CardBody>
                         {
                          <p>No data to display.</p>
                       /* <Table
                        columns={this.state.columns}
                        dataSource={this.getTableData()} // getTableData returns a properly formatted array
                        pagination={{ pageSize: 5 }}
                        bordered
                      />*/
                        /* <Spin
                            // spinning={this.state.isLoadReception}
                            delay={10}
                        // indicator={<AntdIcon type="loading" style={{ fontSize: 24 }} spin={"true"} />}
                        > */}
                        
                        {/* </Spin> */}
                    </CardBody>
                </Card>
            </div>
        )
    }
}

export default App;
